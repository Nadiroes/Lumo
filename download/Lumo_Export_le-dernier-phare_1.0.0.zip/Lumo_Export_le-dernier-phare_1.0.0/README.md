# Export Lumo — Le Dernier Phare

Archive générée automatiquement par **Lumo** le 03/11/2026 22:40:17.

| | |
|---|---|
| Version | **1.0.0** |
| Export n° | 1 |
| Mode | book |
| Messages | 1 |
| Artefacts | 1 |
| Fichiers | 7 (19.9 Ko) |

## Contenu

```
Lumo_Export_le-dernier-phare_1.0.0/
├── manifest.json          ← intégrité + généalogie du versioning
├── README.md
├── conversation/
│   ├── transcript.json    ← structure complète (rôles, horodatages, IDs)
│   └── transcript.md      ← version lisible
├── artifacts/             ← images, audio, vidéo, textes générés
└── metadata/
    ├── providers.json     ← quel modèle a produit quoi
    └── checksums.sha256   ← empreintes SHA-256
```

## Vérifier l’intégrité

```bash
shasum -a 256 -c metadata/checksums.sha256
```

> Archive autonome : elle ne dépend d’aucun serveur Lumo pour être relue.
